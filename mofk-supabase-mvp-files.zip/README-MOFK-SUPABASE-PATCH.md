# Mofk Supabase MVP Patch

I could not commit directly to GitHub because the GitHub integration returned `403 Resource not accessible by integration`.
Copy these files into your repo paths exactly.

## Files to add/replace

1. Add:
   - `artifacts/mfk-web/src/lib/supabase.ts`
   - `artifacts/mfk-web/src/lib/supabase-api-bridge.ts`
   - `artifacts/mfk-web/.env.example`
   - `supabase/mofk_schema.sql`

2. Replace:
   - `artifacts/mfk-web/src/contexts/AuthContext.tsx`
   - `artifacts/mfk-web/src/main.tsx`

## Supabase setup

1. Open Supabase.
2. Go to SQL Editor.
3. Run `supabase/mofk_schema.sql`.
4. Go to Authentication > Providers > Email.
5. For the MVP test, disable email confirmation if you want register → login to work immediately.
6. Get:
   - Project URL
   - anon public key

## Local env

Create:

`artifacts/mfk-web/.env.local`

with:

```env
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

## Vercel env

Add the same two variables in:

Project > Settings > Environment Variables

Then redeploy.

## Test

1. Register new user.
2. Login.
3. Go to `/app/vehicles`.
4. Add vehicle.
5. Refresh page.
6. Vehicle should remain saved in Supabase.
